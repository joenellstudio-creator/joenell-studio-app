// Joenell Studio Editing — backend (Cloudflare Pages advanced mode).
// - /api/checkout        create a Stripe Checkout session (prices computed here)
// - /api/order           look up a paid order for the upload page
// - /api/upload          store one uploaded file in R2 (paid orders only)
// - /api/upload-complete mark an upload batch as finished
// - /admin               private order list + downloads (password: ADMIN_PASSWORD)
// Everything else is served from the static site.

const RATES = {
  wedding:    { label: "Wedding / events",          tiers: [100, 85, 75] },   // cents per photo
  portrait:   { label: "Portrait / family / other", tiers: [150, 125, 100] },
  realestate: { label: "Real estate",               tiers: [300, 225, 150] },
};
const RETOUCH_CENTS = 300;
const MIN_PHOTOS = 25;
const MAX_PHOTOS = 5000;
const MAX_FILE_BYTES = 100 * 1024 * 1024;
const SID_RE = /^cs_(test|live)_[A-Za-z0-9]+$/;

function rateFor(type, n) {
  const t = RATES[type].tiers;
  return n >= 200 ? t[2] : n >= 100 ? t[1] : t[0];
}

export function quote({ type, n, retouch, rush }) {
  const per = rateFor(type, n);
  const editing = per * n;
  const retouching = retouch ? RETOUCH_CENTS * n : 0;
  const rushFee = rush ? Math.round((editing + retouching) * 0.5) : 0;
  return { per, editing, retouching, rushFee, total: editing + retouching + rushFee };
}

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// ---------- Stripe ----------
async function stripe(env, path, init = {}) {
  const res = await fetch("https://api.stripe.com/v1/" + path, {
    ...init,
    headers: { Authorization: `Bearer ${env.STRIPE_SECRET_KEY}`, ...(init.headers || {}) },
  });
  return { ok: res.ok, data: await res.json() };
}

const paidCache = new Map(); // per-isolate cache of verified sessions
async function paidSession(env, sid) {
  if (!SID_RE.test(sid)) return null;
  if (paidCache.has(sid)) return paidCache.get(sid);
  const { ok, data } = await stripe(env, "checkout/sessions/" + encodeURIComponent(sid));
  if (!ok || data.payment_status !== "paid") return null;
  const m = data.metadata || {};
  const order = {
    session_id: sid,
    name: m.customer_name || data.customer_details?.name || "",
    email: data.customer_details?.email || data.customer_email || "",
    shoot_type: m.shoot_type || "",
    photos: m.photos || "",
    retouching: m.retouching || "",
    turnaround: m.turnaround || "",
    country: m.country || "",
    notes: m.notes || "",
    amount_paid: ((data.amount_total || 0) / 100).toFixed(2) + " " + String(data.currency || "").toUpperCase(),
    paid_at: new Date((data.created || 0) * 1000).toISOString(),
    livemode: !!data.livemode,
  };
  paidCache.set(sid, order);
  return order;
}

async function ensureOrderRecord(env, order) {
  const key = `orders/${order.session_id}/order.json`;
  if (!(await env.UPLOADS.head(key))) {
    await env.UPLOADS.put(key, JSON.stringify(order, null, 2), { httpMetadata: { contentType: "application/json" } });
  }
}

async function countFiles(env, sid) {
  const out = { photos: 0, style: 0, bytes: 0 };
  for (const kind of ["photos", "style"]) {
    let cursor;
    do {
      const r = await env.UPLOADS.list({ prefix: `orders/${sid}/${kind}/`, cursor });
      out[kind] += r.objects.length;
      for (const o of r.objects) out.bytes += o.size;
      cursor = r.truncated ? r.cursor : undefined;
    } while (cursor);
  }
  return out;
}

// ---------- Checkout ----------
async function createCheckout(request, env) {
  if (!env.STRIPE_SECRET_KEY) return json({ error: "Payments are not set up yet." }, 503);
  let b;
  try { b = await request.json(); } catch { return json({ error: "Invalid request." }, 400); }

  const type = String(b.type || "");
  const n = parseInt(b.n, 10);
  const retouch = !!b.retouch;
  const rush = !!b.rush;
  const name = String(b.name || "").trim().slice(0, 100);
  const email = String(b.email || "").trim().slice(0, 200);
  const country = String(b.country || "").slice(0, 40);
  const notes = String(b.notes || "").slice(0, 450);

  if (!RATES[type]) return json({ error: "Choose a type of shoot." }, 400);
  if (!Number.isFinite(n) || n < MIN_PHOTOS || n > MAX_PHOTOS)
    return json({ error: `Photo count must be between ${MIN_PHOTOS} and ${MAX_PHOTOS}.` }, 400);
  if (!name) return json({ error: "Add your name." }, 400);
  if (!/^\S+@\S+\.\S+$/.test(email)) return json({ error: "Enter a valid email." }, 400);

  const q = quote({ type, n, retouch, rush });
  const origin = new URL(request.url).origin;
  const label = RATES[type].label;

  const p = new URLSearchParams();
  p.append("mode", "payment");
  p.append("customer_email", email);
  p.append("success_url", `${origin}/upload?session_id={CHECKOUT_SESSION_ID}`);
  p.append("cancel_url", `${origin}/?order=cancelled#order`);
  p.append("billing_address_collection", "required");
  p.append("custom_text[submit][message]",
    "After payment you'll go straight to your private upload page. By paying you agree to our terms and refund policy at joenellstudio.com/terms.");

  let i = 0;
  const line = (productName, unitCents, qty) => {
    p.append(`line_items[${i}][price_data][currency]`, "usd");
    p.append(`line_items[${i}][price_data][product_data][name]`, productName);
    p.append(`line_items[${i}][price_data][unit_amount]`, String(unitCents));
    p.append(`line_items[${i}][quantity]`, String(qty));
    i++;
  };
  line(`Photo editing — ${label} (color correction + culling)`, q.per, n);
  if (retouch) line("Retouching add-on", RETOUCH_CENTS, n);
  if (rush) line("Rush 24-hour turnaround (+50%)", q.rushFee, 1);

  const meta = {
    customer_name: name, shoot_type: label, photos: String(n),
    retouching: retouch ? "yes" : "no", turnaround: rush ? "24 hours" : "3 days",
    country, notes,
  };
  for (const [k, v] of Object.entries(meta)) {
    p.append(`metadata[${k}]`, v);
    p.append(`payment_intent_data[metadata][${k}]`, v);
  }
  p.append("payment_intent_data[description]",
    `${n} photos · ${label}${retouch ? " + retouching" : ""} · ${rush ? "24h rush" : "3 days"}`);

  const { ok, data } = await stripe(env, "checkout/sessions", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: p,
  });
  if (!ok) return json({ error: "Could not start checkout. Please try again." }, 502);
  return json({ url: data.url });
}

// ---------- Uploads ----------
async function getOrder(url, env) {
  if (!env.UPLOADS) return json({ error: "Uploads are not set up yet. Please email joenellstudio@gmail.com." }, 503);
  const order = await paidSession(env, url.searchParams.get("session_id") || "");
  if (!order) return json({ error: "We couldn't find a paid order for this link. Please email joenellstudio@gmail.com." }, 404);
  await ensureOrderRecord(env, order);
  const c = await countFiles(env, order.session_id);
  return json({
    name: order.name, shoot_type: order.shoot_type, photos: order.photos,
    retouching: order.retouching, turnaround: order.turnaround,
    uploaded: { photos: c.photos, style: c.style },
  });
}

function safeName(name) {
  const base = String(name || "file").split(/[\\/]/).pop()
    .replace(/[\u0000-\u001f\u007f]/g, "").replace(/[^\w.\- ()]/g, "_").trim().slice(0, 150);
  return base && !/^\.+$/.test(base) ? base : "file";
}

async function putUpload(request, url, env) {
  if (!env.UPLOADS) return json({ error: "Uploads are not set up yet." }, 503);
  const sid = url.searchParams.get("session_id") || "";
  const kind = url.searchParams.get("kind");
  if (kind !== "photos" && kind !== "style") return json({ error: "Unknown upload type." }, 400);
  const len = parseInt(request.headers.get("content-length") || "0", 10);
  if (!len) return new Response("Empty file", { status: 400 });
  if (len > MAX_FILE_BYTES) return new Response("File is over 100 MB", { status: 413 });
  const order = await paidSession(env, sid);
  if (!order) return new Response("Order not found or not paid", { status: 403 });
  await ensureOrderRecord(env, order);
  const key = `orders/${sid}/${kind}/${safeName(url.searchParams.get("name"))}`;
  await env.UPLOADS.put(key, request.body, {
    httpMetadata: { contentType: request.headers.get("content-type") || "application/octet-stream" },
  });
  return json({ ok: true });
}

async function uploadComplete(url, env) {
  if (!env.UPLOADS) return json({ error: "Uploads are not set up yet." }, 503);
  const order = await paidSession(env, url.searchParams.get("session_id") || "");
  if (!order) return json({ error: "Order not found." }, 404);
  const c = await countFiles(env, order.session_id);
  await env.UPLOADS.put(`orders/${order.session_id}/status.json`,
    JSON.stringify({ last_upload_at: new Date().toISOString(), ...c }), { httpMetadata: { contentType: "application/json" } });
  return json({ ok: true, ...c });
}

// ---------- Admin ----------
function adminAuthorized(request, env) {
  if (!env.ADMIN_PASSWORD) return false;
  const h = request.headers.get("authorization") || "";
  if (!h.startsWith("Basic ")) return false;
  let decoded = "";
  try { decoded = atob(h.slice(6)); } catch { return false; }
  const pass = decoded.slice(decoded.indexOf(":") + 1);
  if (pass.length !== env.ADMIN_PASSWORD.length) return false;
  let diff = 0;
  for (let i = 0; i < pass.length; i++) diff |= pass.charCodeAt(i) ^ env.ADMIN_PASSWORD.charCodeAt(i);
  return diff === 0;
}

const adminPage = (title, body) => new Response(`<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>${esc(title)} · Joenell Studio Editing admin</title>
<style>
:root{--bg:#f3f5f8;--surface:#fff;--ink:#151a22;--muted:#5a6475;--line:#d9dee7;--accent:#2457d6;--err:#c2362b;--ok:#1d8a5b}
@media (prefers-color-scheme:dark){:root{--bg:#0f131a;--surface:#171c25;--ink:#e9edf4;--muted:#9aa4b5;--line:#2a3240;--accent:#6f97ff;--err:#ff7a6e;--ok:#4cc38a;color-scheme:dark}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,sans-serif}
.wrap{max-width:1000px;margin:0 auto;padding:24px max(16px,env(safe-area-inset-left))}
h1{font-size:1.6rem;margin:0 0 4px}a{color:var(--accent)}.muted{color:var(--muted)}
table{width:100%;border-collapse:collapse;background:var(--surface);border:1px solid var(--line);border-radius:8px;overflow:hidden}
th,td{text-align:left;padding:10px 12px;border-bottom:1px solid var(--line);vertical-align:top}th{font-size:.8rem;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
.scroll{overflow-x:auto}.pill{display:inline-block;padding:2px 8px;border-radius:999px;font-size:.8rem;border:1px solid var(--line)}
.pill.ok{border-color:var(--ok);color:var(--ok)}.pill.wait{border-color:var(--muted);color:var(--muted)}.pill.test{border-color:var(--err);color:var(--err)}
.btn{font:600 .95rem system-ui;padding:.6em 1.1em;border-radius:999px;border:1.5px solid var(--accent);background:var(--accent);color:#fff;cursor:pointer;text-decoration:none;display:inline-block}
.btn.ghost{background:transparent;color:var(--accent)}.btn.danger{border-color:var(--err);background:transparent;color:var(--err)}
dl{display:grid;grid-template-columns:max-content 1fr;gap:6px 16px;background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:16px}dt{color:var(--muted)}dd{margin:0}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:16px 0}
</style></head><body><div class="wrap">${body}</div></body></html>`,
  { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "x-robots-tag": "noindex" } });

async function listAll(env, prefix) {
  const out = [];
  let cursor;
  do {
    const r = await env.UPLOADS.list({ prefix, cursor });
    out.push(...r.objects);
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
  return out;
}

async function adminHome(env) {
  const prefixes = [];
  let cursor;
  do {
    const r = await env.UPLOADS.list({ prefix: "orders/", delimiter: "/", cursor });
    prefixes.push(...r.delimitedPrefixes);
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
  const orders = [];
  for (const pfx of prefixes) {
    const sid = pfx.slice("orders/".length, -1);
    const o = await env.UPLOADS.get(`${pfx}order.json`);
    const s = await env.UPLOADS.get(`${pfx}status.json`);
    orders.push({ sid, order: o ? await o.json() : { session_id: sid }, status: s ? await s.json() : null });
  }
  orders.sort((a, b) => String(b.order.paid_at || "").localeCompare(String(a.order.paid_at || "")));
  const rows = orders.map(({ sid, order, status }) => `<tr>
    <td>${esc((order.paid_at || "").slice(0, 10))}</td>
    <td><a href="/admin/order?sid=${encodeURIComponent(sid)}">${esc(order.name || "(no name)")}</a><br><span class="muted">${esc(order.email)}</span></td>
    <td>${esc(order.shoot_type)}<br><span class="muted">${esc(order.photos)} photos · retouch ${esc(order.retouching)}</span></td>
    <td>${esc(order.turnaround)}</td>
    <td>${status ? `<span class="pill ok">${status.photos} photos · ${status.style} samples</span>` : `<span class="pill wait">Waiting for upload</span>`}
        ${order.livemode === false ? ' <span class="pill test">test</span>' : ""}</td>
    <td>${esc(order.amount_paid)}</td></tr>`).join("");
  return adminPage("Orders", `<h1>Orders</h1><p class="muted">${orders.length} order(s) with an upload page opened. Newest first.</p>
    <div class="scroll"><table><thead><tr><th>Paid</th><th>Customer</th><th>Order</th><th>Turnaround</th><th>Uploads</th><th>Paid</th></tr></thead>
    <tbody>${rows || `<tr><td colspan="6" class="muted">No orders yet. They appear here once a customer pays and opens their upload page.</td></tr>`}</tbody></table></div>`);
}

async function adminOrder(url, env) {
  const sid = url.searchParams.get("sid") || "";
  if (!SID_RE.test(sid)) return new Response("Bad order id", { status: 400 });
  const o = await env.UPLOADS.get(`orders/${sid}/order.json`);
  const order = o ? await o.json() : { session_id: sid };
  const files = (await listAll(env, `orders/${sid}/`)).filter((f) => /\/(photos|style)\//.test(f.key));
  const total = files.reduce((s, f) => s + f.size, 0);
  const link = (f) => `/admin/file?key=${encodeURIComponent(f.key)}`;
  const list = (kind) => files.filter((f) => f.key.includes(`/${kind}/`)).map((f) =>
    `<tr><td><a href="${link(f)}">${esc(f.key.split("/").pop())}</a></td><td>${(f.size / 1e6).toFixed(1)} MB</td></tr>`).join("") ||
    `<tr><td colspan="2" class="muted">None yet</td></tr>`;
  return adminPage(order.name || "Order", `<p><a href="/admin">← All orders</a></p>
    <h1>${esc(order.name || "Order")}</h1>
    <dl><dt>Email</dt><dd>${esc(order.email)}</dd><dt>Shoot</dt><dd>${esc(order.shoot_type)}</dd>
    <dt>Photos to deliver</dt><dd>${esc(order.photos)}</dd><dt>Retouching</dt><dd>${esc(order.retouching)}</dd>
    <dt>Turnaround</dt><dd>${esc(order.turnaround)}</dd><dt>Country</dt><dd>${esc(order.country)}</dd>
    <dt>Notes</dt><dd>${esc(order.notes) || "—"}</dd><dt>Paid</dt><dd>${esc(order.amount_paid)} on ${esc((order.paid_at || "").slice(0, 10))}</dd>
    <dt>Stripe session</dt><dd><code>${esc(sid)}</code></dd></dl>
    <div class="row"><button class="btn" id="all">Download all ${files.length} files (${(total / 1e9).toFixed(2)} GB)</button>
    <form method="post" action="/admin/delete?sid=${encodeURIComponent(sid)}" id="del">
      <button class="btn danger" type="button" id="del1">Delete this order's files</button>
      <button class="btn danger" type="submit" id="del2" hidden>Yes, permanently delete ${files.length} files</button></form></div>
    <p class="muted" id="msg">Chrome may ask once to allow multiple downloads. Files save to your Downloads folder.</p>
    <h2>Photos to edit</h2><div class="scroll"><table><tbody>${list("photos")}</tbody></table></div>
    <h2>Sample edits (style)</h2><div class="scroll"><table><tbody>${list("style")}</tbody></table></div>
    <script>
    var links=${JSON.stringify(files.map(link))};
    document.getElementById('all').onclick=function(){var i=0,m=document.getElementById('msg');
      (function step(){if(i>=links.length){m.textContent='Started all '+links.length+' downloads.';return}
        var a=document.createElement('a');a.href=links[i]+'&dl=1';a.download='';document.body.appendChild(a);a.click();a.remove();
        i++;m.textContent='Starting download '+i+' of '+links.length+'…';setTimeout(step,400)})();};
    document.getElementById('del1').onclick=function(){this.hidden=true;document.getElementById('del2').hidden=false};
    </script>`);
}

async function adminFile(url, env) {
  const key = url.searchParams.get("key") || "";
  if (!key.startsWith("orders/") || key.includes("..")) return new Response("Bad key", { status: 400 });
  const obj = await env.UPLOADS.get(key);
  if (!obj) return new Response("Not found", { status: 404 });
  const name = key.split("/").pop();
  const sid = key.split("/")[1];
  const kind = key.split("/")[2];
  return new Response(obj.body, {
    headers: {
      "content-type": obj.httpMetadata?.contentType || "application/octet-stream",
      "content-disposition": `attachment; filename="${sid.slice(-8)}_${kind}_${name.replace(/"/g, "")}"`,
      "cache-control": "private, no-store",
    },
  });
}

async function adminDelete(url, env) {
  const sid = url.searchParams.get("sid") || "";
  if (!SID_RE.test(sid)) return new Response("Bad order id", { status: 400 });
  const files = (await listAll(env, `orders/${sid}/`)).filter((f) => /\/(photos|style)\//.test(f.key));
  for (let i = 0; i < files.length; i += 500) await env.UPLOADS.delete(files.slice(i, i + 500).map((f) => f.key));
  await env.UPLOADS.put(`orders/${sid}/status.json`,
    JSON.stringify({ deleted_at: new Date().toISOString(), photos: 0, style: 0, bytes: 0 }), { httpMetadata: { contentType: "application/json" } });
  return Response.redirect(new URL(`/admin/order?sid=${encodeURIComponent(sid)}`, url).toString(), 303);
}

async function admin(request, url, env) {
  if (!env.ADMIN_PASSWORD) return new Response("Admin is not set up yet (add ADMIN_PASSWORD in Cloudflare).", { status: 503 });
  if (!adminAuthorized(request, env))
    return new Response("Sign in required", { status: 401, headers: { "WWW-Authenticate": 'Basic realm="Joenell Studio admin", charset="UTF-8"' } });
  if (!env.UPLOADS) return new Response("Uploads storage is not connected yet.", { status: 503 });
  const p = url.pathname.replace(/\/+$/, "");
  if (p === "/admin") return adminHome(env);
  if (p === "/admin/order") return adminOrder(url, env);
  if (p === "/admin/file") return adminFile(url, env);
  if (p === "/admin/delete" && request.method === "POST") return adminDelete(url, env);
  return new Response("Not found", { status: 404 });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const p = url.pathname;
    const notAllowed = () => json({ error: "Method not allowed." }, 405);
    try {
      if (p === "/api/checkout") return request.method === "POST" ? await createCheckout(request, env) : notAllowed();
      if (p === "/api/order") return await getOrder(url, env);
      if (p === "/api/upload") return request.method === "PUT" ? await putUpload(request, url, env) : notAllowed();
      if (p === "/api/upload-complete") return request.method === "POST" ? await uploadComplete(url, env) : notAllowed();
      if (p === "/admin" || p.startsWith("/admin/")) return await admin(request, url, env);
    } catch (e) {
      return json({ error: "Something went wrong. Please try again or email joenellstudio@gmail.com." }, 500);
    }
    return env.ASSETS.fetch(request);
  },
};
